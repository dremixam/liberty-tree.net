Manana Black Beauty - R�alis�e par NelsoN le 08/09/02
-----------------------------------------------------------------------------------------------------------------------
Tout d'abord, merci d'avoir choisi mon v�hicule.

L'installation est simple.
Il faut avoir TXDtool (peu importe la version) et ouvrir TXD.img qui se trouve dans
***\Rockstar Games\GTAIII\models

Faites un clic gauche sur Manana.txd dans la liste de gauche.
 dans la liste de droite, faites un clic gauche puis un clic droit sur manana8bit128 et allez sur Import => texture
et choisissez la texture qui se trouve dans ce zip.

Ensuite, ouvrez le fichier "handling.cfg" qui se trouve dans GTAIII\data et remplacez la ligne MANANA par la ligne suivant:

Fermez en sauvegardant vos changements.

MANANA          1700.0 2.0 4.9 1.6 0.0 0.2  0.0  75  0.95 0.80 0.55 5 280.0 50.0 4 P 11.5  0.53 1 30.0  2.0  0.13 0.2  0.50 35000 0.20 -0.10 0.5  8002		0  1
 
Ouvrez "Carcols.dat" qui se trouve dans GTAIII\data avec Bloc note et remplacez la ligne "manana" par la suivante:

manana, 0,1, 24,72, 34,73, 44,74, 54,75, 64,72, 57,73, 48,74, 26,75
 
Fermez en sauvegardant vos changements.

une suggestion, un commentaire? Creative.art@wanadoo.fr

Have Fun!!

NelsoN
